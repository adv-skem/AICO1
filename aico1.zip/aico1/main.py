from four_part_harmony import tenor_parts as ano
from four_part_harmony import mezzo_parts as mpao
import musicpy as mp
x = mpao.mezzo_voice(['C5', 'G4', 'E4', 'E4', 'F4', 'G4', 'C5'])
def main():
    s = mp.chord(x.melody,
                 interval=[0.5 for i in range(len(x.melody))],
                 duration=0.5)
    b = mp.chord(x.bass_ways_of_choice,
                 interval=[0.5 for i in range(len(x.melody))],
                 duration=0.5)
    t = mp.chord(x.tenor_ways_of_choice,
                 interval=[0.5 for i in range(len(x.melody))],
                 duration=0.5)
    if x.mezzo_dic:
        m = mp.chord(x.mezzo_dic[0],
                     interval=[0.5 for i in range(len(x.melody))],
                     duration=0.5)
    else:
        m = s
    song3 = mp.build([s], [b], [t], [m], bpm=150)
    mp.play(song3, wait=True)
main()