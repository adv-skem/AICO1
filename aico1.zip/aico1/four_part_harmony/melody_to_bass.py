from script import note as nt
from script import tune as tu
from four_part_harmony import note_and_number as nn
from script import function_chords as fc
import itertools
import networkx as nx
import matplotlib.pyplot as plt
import mpld3


class MelodyToBass:
    def __init__(self, melody):

        self.melody = melody
        self.melody_number = []
        self.bass = []
        self.bass_grade_mess = []
        self.wild_bass_grade = []
        self.no_ds_bass_grade = []
        self.no_ds_bass_grade2 = []
        self.grade_series = []
        self.wild_bass = []
        self.use_list = []

        self.layer_graph = nx.Graph()

        self.all_path_dic = {}
        self.all_option_dic = {}
        self.wild_bass_dic = {}
        self.mega_interval = {}

        self.note_to_grade()
        self.grade_to_chord_basic()
        self.remove_DS_and_other_mess()
        self.grade_to_bass()
        self.mode = input('你想要哪种和声进行？输入对应的字典号:')
        print(self.all_option_dic[int(self.mode)])
        self.choose_the_bass(self.mode)
        self.link_the_graph()
        self.visualize()
        self.find_the_best_path()

    def get_melody_number(self):
        for i in self.melody:
            self.melody_number.append(nn.note2number(i))
        return self.melody_number

    def note_to_grade(self):
        for note in self.melody:
            if note not in tu.C_major_mapping.keys():
                print("Invalid note")
                return "Invalid note"
            elif nn.note2number(note) < 20:
                print('too low')
                return 'too low'
            elif nn.note2number(note) > 57 / 2:
                print('too high')
                return 'too high'
            elif 2 * nn.note2number(note) % 12 == 0:
                self.grade_series.append(fc.grade_notes[0])
            elif 2 * nn.note2number(note) % 12 == 2:
                self.grade_series.append(fc.grade_notes[1])
            elif 2 * nn.note2number(note) % 12 == 4:
                self.grade_series.append(fc.grade_notes[2])
            elif 2 * nn.note2number(note) % 12 == 5:
                self.grade_series.append(fc.grade_notes[3])
            elif 2 * nn.note2number(note) % 12 == 7:
                self.grade_series.append(fc.grade_notes[4])
            elif 2 * nn.note2number(note) % 12 == 9:
                self.grade_series.append(fc.grade_notes[5])
            elif 2 * nn.note2number(note) % 12 == 11:
                self.grade_series.append(fc.grade_notes[6])

        return self.grade_series

    def grade_to_chord_basic(self):

        for grade in self.grade_series:
            if grade == fc.grade_notes[0]:
                self.bass_grade_mess.append(['T', 'S', 'TS_VI'])
            elif grade == fc.grade_notes[1]:
                self.bass_grade_mess.append(['S_II,D'])
            elif grade == fc.grade_notes[2]:
                self.bass_grade_mess.append(['T', 'TS_VI', 'DT_III'])
            elif grade == fc.grade_notes[3]:
                self.bass_grade_mess.append(['S', 'D_VII'])
            elif grade == fc.grade_notes[4]:
                self.bass_grade_mess.append(['T', 'D', 'DT_III'])
            elif grade == fc.grade_notes[5]:
                self.bass_grade_mess.append(['S_II', 'TS_VI'])
            elif grade == fc.grade_notes[6]:
                self.bass_grade_mess.append(['D', 'DT_III'])
        for combination in itertools.product(*self.bass_grade_mess):
            self.wild_bass_grade.append(list(combination))

        return self.wild_bass_grade

    def remove_DS_and_other_mess(self):

        self.no_ds_bass_grade = [sub for sub in self.wild_bass_grade
                                 if 'DS' not in ''.join(sub)
                                 and 'TTT' not in ''.join(sub)
                                 and 'DDD' not in ''.join(sub)
                                 and 'SSS' not in ''.join(sub)
                                 and 'DS_II' not in ''.join(sub)
                                 and 'TS_VITS_VI' not in ''.join(sub)
                                 and 'DT_IIIDT_III' not in ''.join(sub)
                                 and 'D_VIID_VII' not in ''.join(sub)
                                 ]
        self.no_ds_bass_grade2 = [sub for sub in self.no_ds_bass_grade
                                  if sub[-1] == 'T'
                                  and sub[0] == 'T']

        middlenum = len(self.no_ds_bass_grade2)
        self.all_option_dic = nn.create_empty_lists(middlenum)
        for i in range(1, middlenum + 1):
            self.all_option_dic[i] = self.no_ds_bass_grade2[i - 1]
        print('====================================================')
        print('所有可能的功能进行:')
        print(self.all_option_dic)
        print('====================================================')
        return self.no_ds_bass_grade2

    def grade_to_bass(self):
        for piece in self.no_ds_bass_grade2:
            for grade in piece:
                if grade == fc.all_chords[0]:
                    self.wild_bass.append(['C3', 'E3', 'E2', 'G3', 'G2'])
                elif grade == fc.all_chords[1]:
                    self.wild_bass.append(['D3', 'F3', 'F2', 'A2', 'A3'])
                elif grade == fc.all_chords[2]:
                    self.wild_bass.append(['E3', 'E2', 'G2', 'G3', 'B2'])
                elif grade == fc.all_chords[3]:
                    self.wild_bass.append(['F3', 'F2', 'A2', 'A3', 'C3'])
                elif grade == fc.all_chords[4]:
                    self.wild_bass.append(['G3', 'G2', 'B2', 'B3', 'D2'])
                elif grade == fc.all_chords[5]:
                    self.wild_bass.append(['A3', 'A2', 'C2', 'E2', 'E3'])
                elif grade == fc.all_chords[6]:
                    self.wild_bass.append(['B3', 'B2', 'D2', 'F2', 'F3'])

        length = len(self.no_ds_bass_grade2)

        self.wild_bass_dic = nn.create_empty_lists(length)

        print('++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
        num = 0

        for i in range(1, length + 1):
            for j in range(len(self.melody)):
                self.wild_bass_dic[i].append(self.wild_bass[num])

                num += 1

        print('++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')

        return self.wild_bass_dic

    def choose_the_bass(self, mode):
        layered_graph = nx.Graph()
        use_list = self.wild_bass_dic[int(mode)]
        self.use_list = use_list
        print("!!!!可使用列表:!!!!")
        print(use_list)
        level_use_list = []
        for i in range(len(use_list)):
            for j in range(len(use_list[i])):
                level_use_list.append(use_list[i][j] + ' level:' + str(i + 1))

        level_dic = nn.create_empty_lists(len(use_list))

        for i in range(len(use_list)):
            for j, note in enumerate(use_list[i]):
                if i + 1 not in level_dic:
                    level_dic[i + 1] = [note + ' level:' + str(i + 1)]
                else:
                    level_dic[i + 1].append(note + ' level:' + str(i + 1))

        for i in range(len(level_dic)):
            for node in level_dic[i + 1]:
                node_name = node.split(' level:')[0]
                layered_graph.add_node(node, level=i + 1,
                                       interval_with_melody=nn.calculate_interval(node_name, self.melody[i]))

        self.layer_graph = layered_graph

        return self.layer_graph

    def link_the_graph(self):

        for i in range(1, len(self.use_list)):
            current_level = self.use_list[i]
            last_level = self.use_list[i - 1]

            for note in current_level:
                for last_note in last_level:
                    self.layer_graph.add_edge(last_note + ' level:' + str(i), note + ' level:' + str(i + 1),
                                              level=i, label=nn.calculate_interval(note, last_note))

            print("=============================================")
            print('第' + str(i + 1) + '层')
            print(current_level)
        print('===================================================')

        # Ensure all nodes have the 'level' attribute
        for node, data in self.layer_graph.nodes(data=True):
            data['level'] = data.get('level', 0)
        # Connect the second last layer to the last layer with 'C3'
        second_last_level = self.use_list[-2]

        for note in second_last_level:
            self.layer_graph.add_edge(note + ' level:' + str(len(self.use_list) - 1),
                                      'C3 level:' + str(len(self.use_list)),
                                      level=len(self.use_list) - 1)

        # 对图的所有的边:如果其label大于4,且不等于6,去除这条边
        edges_to_remove1 = [(u, v) for u, v, d in self.layer_graph.edges(data=True) if
                            'label' in d and d['label'] > 4 and d['label'] != 6]
        self.layer_graph.remove_edges_from(edges_to_remove1)

        edges_to_remove2 = []
        for u, v in self.layer_graph.edges():
            if ('interval_with_melody' in self.layer_graph.nodes[u] and 'interval_with_melody' in
                    self.layer_graph.nodes[v]):
                interval_u = self.layer_graph.nodes[u]['interval_with_melody']
                interval_v = self.layer_graph.nodes[v]['interval_with_melody']
                if (interval_u == nt.interval['小十六'] and interval_v == nt.interval['小十六']) or (
                        interval_u == nt.interval['大十三'] and interval_v == nt.interval['大十三']) or (
                        interval_u == nt.interval['小十六'] and interval_v == nt.interval['纯八']) or (
                        interval_u == nt.interval['纯八'] and interval_v == nt.interval['小十六']):
                    edges_to_remove2.append((u, v))
                # print(f"Nodes {u} and {v} have intervals: {interval_u} and {interval_v}")

        self.layer_graph.remove_edges_from(edges_to_remove2)
        return self.layer_graph

    # 这个没用上
    def calculate_mega_interval(self):
        self.mega_interval = nn.create_empty_lists(len(self.use_list))
        edge_dic = nn.create_empty_lists(len(self.use_list) - 1)

        # 将self.layer_graph的所有边依据层来加入self.edge_dic的对应项
        for u, v in self.layer_graph.edges():
            data = self.layer_graph[u][v]
            level = data['level']
            if 'label' in data:
                label = data['label']
            else:
                label = None

            edge_dic[level].append(label)
        return edge_dic

    def visualize(self):
        plt.figure(figsize=(15, 8))

        pos = nx.multipartite_layout(self.layer_graph, subset_key="level", align='vertical')
        nx.draw(self.layer_graph, pos, with_labels=True, node_size=500, node_color='skyblue', font_size=12,
                font_weight='bold')
        edge_labels = {(u, v): d['label'] for u, v, d in self.layer_graph.edges(data=True) if 'label' in d}  # 获取边上的标签
        nx.draw_networkx_edge_labels(self.layer_graph, pos, edge_labels=edge_labels, font_color='red')  # 添加边上的标签
        plt.title("Layered Graph Visualization")
        plt.show()

    def find_the_best_path(self):

        all_paths = []
        start_node = 'C3 level:1'  # 第一层的C3节点
        end_node = 'C3 level:' + str(len(self.use_list))  # 最后一层的C3节点

        def is_valid_edge(node1, node2):
            return self.layer_graph.has_edge(node1, node2)

        def dfs(current_path, current_node):
            if current_node == end_node:
                all_paths.append(current_path)
                return
            for neighbor in self.layer_graph.neighbors(current_node):
                if int(neighbor.split(' level:')[1]) > int(current_node.split(' level:')[1]) and is_valid_edge(
                        current_node, neighbor):
                    dfs(current_path + [neighbor.split(' level:')[0]], neighbor)

        dfs([], start_node)
        for path in all_paths:
            path.insert(0, 'C3')

        self.all_path_dic = nn.create_empty_lists(len(all_paths))
        for i in range(1, len(all_paths) + 1):
            self.all_path_dic[i] = all_paths[i - 1]
        print('=======================================================================')
        print('所有低音线条')
        print(self.all_path_dic)
        print('=======================================================================')

        return self.all_path_dic

# a=MelodyToBass(['C5', 'G4', 'E4', 'E4', 'F4', 'G4', 'C5'])
