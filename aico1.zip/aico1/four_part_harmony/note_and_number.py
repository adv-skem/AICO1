from script import note as nt
from script import function_chords as fc
from script import tune as tun


def note2number(note):
    if note not in nt.note_mapping.keys():
        return "Invalid note"
    else:
        return nt.note_mapping[note]


def number2note(number):
    if number not in nt.reversed_use_note1.keys():
        return "Invalid number"
    else:
        return nt.reversed_use_note1[number]


def calculate_interval(note1, note2):
    if note1 not in nt.note_mapping or note2 not in nt.note_mapping:
        return "错误：音符不在映射字典中"

    pitch_difference = abs(note2number(note1) - note2number(note2))

    return pitch_difference


def high_possible_notes(note, number):
    if note not in nt.note_mapping.keys():
        return "Invalid note"
    if number not in nt.reversed_use_note1.keys():
        return "Invalid number"
    return nt.reversed_use_note1[nt.use_note1[note] + number]


def low_possible_notes(note, number):
    if note not in nt.note_mapping.keys():
        return "Invalid number"
    if number not in nt.reversed_use_note1.keys():
        return "Invalid number"
    return nt.reversed_use_note1[nt.use_note1[note] - number]


def create_empty_lists(n):
    empty_lists = {}
    for i in range(1, n + 1):
        empty_lists[i] = []
    return empty_lists
