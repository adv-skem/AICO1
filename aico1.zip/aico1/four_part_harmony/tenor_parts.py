import musicpy as mp

import random
from four_part_harmony import melody_to_bass as mel_bass
from four_part_harmony import note_and_number as nn
import networkx as nx
from script import note as nt
import matplotlib.pyplot as plt


class whole_harmony(mel_bass.MelodyToBass):
    def __init__(self, melody):
        super().__init__(melody)
        self.current_chord_level = []
        self.choice = int(input('想选择哪个低音线条？'))
        self.bass_ways_of_choice = self.all_path_dic[self.choice]
        self.current_notes = {}
        self.tenor_graph = nx.Graph()

        self.create_tenor()
        self.check_the_repeat_note()
        self.link_the_tenor_graph()
        self.find_the_tenor_path()
        self.visualize1()

    # 选择一条低音同时在self.no_ds_bass_grade2里选择一个功能进行
    # 设计声部平滑
    # 注意和弦重复音
    # 禁止平五平八

    def check_the_repeat_note(self):
        self.current_notes = nn.create_empty_lists(len(self.melody))
        for i in range(1, len(self.melody) + 1):
            self.current_notes[i].append(self.melody[i - 1])
            self.current_notes[i].append(self.bass_ways_of_choice[i - 1])

        # 待补全
        print('当前的和弦')
        print(self.current_notes)
        print('==================================================')

    def create_tenor(self):
        level_use_list = []
        self.current_chord_level = self.all_option_dic[int(self.mode)]
        for i in range(len(self.use_list)):
            for j in range(len(self.use_list[i])):
                level_use_list.append(self.use_list[i][j] + ' level:' + str(i + 1))

        level_dic = nn.create_empty_lists(len(self.use_list))
        for i in range(len(self.use_list)):
            for j, note in enumerate(self.use_list[i]):
                if i + 1 not in level_dic:
                    level_dic[i + 1] = [note + ' level:' + str(i + 1)]
                else:
                    level_dic[i + 1].append(note + ' level:' + str(i + 1))
        for i in range(len(level_dic)):
            for node in level_dic[i + 1]:
                node_name = node.split(' level:')[0]
                self.tenor_graph.add_node(node, level=i + 1,
                                          interval_with_melody=nn.calculate_interval(node_name, self.melody[i]),
                                          interval_with_bass=nn.calculate_interval(node_name,
                                                                                   self.bass_ways_of_choice[i]))

        print('当前的和弦进行')
        print(self.current_chord_level)
        print('=================================================')
        print('当前的旋律')
        print(self.melody)
        print('=================================================')
        print('当前的低音')
        print(self.bass_ways_of_choice)
        print('=================================================')
        return self.tenor_graph

    def link_the_tenor_graph(self):
        for i in range(1, len(self.use_list)):
            current_level = self.use_list[i]
            last_level = self.use_list[i - 1]

            for note in current_level:
                for last_note in last_level:
                    self.tenor_graph.add_edge(last_note + ' level:' + str(i), note + ' level:' + str(i + 1),
                                              level=i, label=nn.calculate_interval(note, last_note))

            # Ensure all nodes have the 'level' attribute
        for node, data in self.tenor_graph.nodes(data=True):
            data['level'] = data.get('level', 0)
            # Connect the second last layer to the last layer with 'C3'
        second_last_level = self.use_list[-2]
        for note in second_last_level:
            self.tenor_graph.add_edge(note + ' level:' + str(len(self.use_list) - 1),
                                      'C3 level:' + str(len(self.use_list)),
                                      level=len(self.use_list) - 1)

        # 对图的所有的边:如果其label大于4,且不等于6,去除这条边
        edges_to_remove1 = [(u, v) for u, v, d in self.tenor_graph.edges(data=True) if
                            'label' in d and d['label'] > 4 and d['label'] != 6]
        self.tenor_graph.remove_edges_from(edges_to_remove1)

        edges_to_remove2 = []
        for u, v in self.tenor_graph.edges():
            if ('interval_with_melody' in self.tenor_graph.nodes[u] and 'interval_with_melody' in
                    self.tenor_graph.nodes[v]):
                interval_u = self.tenor_graph.nodes[u]['interval_with_melody']
                interval_v = self.tenor_graph.nodes[v]['interval_with_melody']
                if (interval_u == nt.interval['小十六'] and interval_v == nt.interval['小十六']) or (
                        interval_u == nt.interval['大十三'] and interval_v == nt.interval['大十三']) or (
                        interval_u == nt.interval['小十六'] and interval_v == nt.interval['纯八']) or (
                        interval_u == nt.interval['纯八'] and interval_v == nt.interval['小十六']) or (
                        interval_u == nt.interval['纯五'] and interval_v == nt.interval['纯五']
                ):
                    edges_to_remove2.append((u, v))
                # print(f"Nodes {u} and {v} have intervals: {interval_u} and {interval_v}")

        self.tenor_graph.remove_edges_from(edges_to_remove2)
        edges_to_remove3 = []
        for u, v in self.tenor_graph.edges():
            if ('interval_with_bass' in self.tenor_graph.nodes[u] and 'interval_with_bass' in
                    self.tenor_graph.nodes[v]):
                interval_u = self.tenor_graph.nodes[u]['interval_with_bass']
                interval_v = self.tenor_graph.nodes[v]['interval_with_bass']
                if (interval_u == nt.interval['小十六'] and interval_v == nt.interval['小十六']) or (
                        interval_u == nt.interval['大十三'] and interval_v == nt.interval['大十三']) or (
                        interval_u == nt.interval['小十六'] and interval_v == nt.interval['纯八']) or (
                        interval_u == nt.interval['纯八'] and interval_v == nt.interval['小十六']) or (
                        interval_u == nt.interval['纯五'] and interval_v == nt.interval['纯五']
                ):
                    edges_to_remove3.append((u, v))
                # print(f"Nodes {u} and {v} have intervals: {interval_u} and {interval_v}")

        self.tenor_graph.remove_edges_from(edges_to_remove3)
        edges_to_remove4 = []
        for i in range(len(self.melody)):
            for u, v in self.tenor_graph.edges():
                # 如果u或v去掉 ' level:i'之后被nn.note2number()函数作用之后大于nn.note2number(self.melody[i]）
                # ,或小于nn.note2number(self.melody[i])，加入edges_to_remove4
                u_note = u.split(' level:')[0]
                v_note = v.split(' level:')[0]
                u_note_position = nn.note2number(u_note)
                v_note_position = nn.note2number(v_note)
                if u_note_position > nn.note2number(self.melody[i]) or v_note_position > nn.note2number(self.melody[i]):
                    edges_to_remove4.append((u, v))
                if u_note_position < nn.note2number(self.bass_ways_of_choice[i]) or v_note_position < nn.note2number(
                        self.bass_ways_of_choice[i]):
                    edges_to_remove4.append((u, v))
        self.tenor_graph.remove_edges_from(edges_to_remove4)

        return self.tenor_graph

    def find_the_tenor_path(self):
        all_paths = []

        start_node = 'G3 level:1'  # 第一层的C3节点
        end_node = 'G3 level:' + str(len(self.use_list))  # 最后一层的C3节点

        def is_valid_tenor_edge(node1, node2):
            return self.tenor_graph.has_edge(node1, node2)

        def dfs_tenor(current_path, current_node):
            if current_node == end_node:
                all_paths.append(current_path)
                return
            for neighbor in self.tenor_graph.neighbors(current_node):
                if int(neighbor.split(' level:')[1]) > int(current_node.split(' level:')[1]) and is_valid_tenor_edge(
                        current_node, neighbor):
                    dfs_tenor(current_path + [neighbor.split(' level:')[0]], neighbor)

        dfs_tenor([], start_node)
        for path in all_paths:
            path.insert(0, 'G3')

        start_node = 'E3 level:1'  # 第一层的C3节点
        end_node = 'E3 level:' + str(len(self.use_list))  # 最后一层的C3节点
        dfs_tenor([], start_node)
        for path in all_paths:
            path.pop(0)
            path.insert(0, 'E3')

        start_node = 'G3 level:1'  # 第一层的C3节点
        end_node = 'E3 level:' + str(len(self.use_list))  # 最后一层的C3节点
        dfs_tenor([], start_node)
        for path in all_paths:
            path.pop(0)
            path.insert(0, 'G3')

        start_node = 'E3 level:1'  # 第一层的C3节点
        end_node = 'G3 level:' + str(len(self.use_list))  # 最后一层的C3节点
        dfs_tenor([], start_node)
        for path in all_paths:
            path.pop(0)
            path.insert(0, 'E3')

        self.all_path_dic = nn.create_empty_lists(len(all_paths))
        for i in range(1, len(all_paths) + 1):
            self.all_path_dic[i] = all_paths[i - 1]

        keys_to_remove = [key for key, value in self.all_path_dic.items() if len(value) != len(self.melody)]
        for key in keys_to_remove:
            del self.all_path_dic[key]

        print('=======================================================================')
        print('所有高音线条')
        print(self.all_path_dic)
        print('=======================================================================')

        return self.all_path_dic

    def visualize1(self):
        plt.figure(figsize=(15, 8))

        pos = nx.multipartite_layout(self.tenor_graph, subset_key="level", align='vertical')
        nx.draw(self.tenor_graph, pos, with_labels=True, node_size=500, node_color='red', font_size=12,
                font_weight='bold')
        edge_labels = {(u, v): d['label'] for u, v, d in self.tenor_graph.edges(data=True) if 'label' in d}  # 获取边上的标签
        nx.draw_networkx_edge_labels(self.tenor_graph, pos, edge_labels=edge_labels, font_color='red')  # 添加边上的标签
        plt.title("Layered Graph Visualization")
        plt.show()

# 旋律必须高于D4！！！！！！！
# x = whole_harmony(['C5', 'G4', 'E4', 'E4', 'F4', 'G4', 'C5'])
