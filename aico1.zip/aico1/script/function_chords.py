basic_functions = ['T', 'S', 'D']
all_functions = ['T', 'S', 'DT', 'TS', 'D']
all_chords = ['T', 'S_II', 'DT_III', 'S', 'D', 'TS_VI', 'D_VII']
three_chords = ['T', 'T_6', 'T_46',
                'S_II', 'S_II6', 'S_II46',
                'DT_III', 'DT_III6', 'DT_III46',
                'S', 'S_6', 'S_46',
                'D', 'D_6', 'D_46',
                'TS_VI', 'TS_VI6', 'TS_VI46',
                'D_VII', 'D_VII6', 'D_VII46']
seven_chords = ['T_7', 'T_56', 'T_34', 'T_2',
                'S_II7', 'S_II56', 'S_II34', 'S_II2',
                'DT_III7', 'DT_III56', 'DT_III34', 'DT_III2',
                'S_7', 'S_56', 'S_34', 'S_2',
                'D_7', 'D_56', 'D_34', 'D_2',
                'TS_VI7', 'TS_VI56', 'TS_VI34', 'TS_VI2',
                'D_VII7', 'D_VII56', 'D_VII34', 'D_VII2']
grade_notes = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']
